Splash Creator Kit

Includes the logos, app icon, avatar and light/night backgrounds linked on
the Creator Kit page, plus colours.json with that page's colour palette.
SVG and PNG versions are included where available.

Clip templates, example creator posts and font files are not included.
See the Creator Kit page for usage guidance.
